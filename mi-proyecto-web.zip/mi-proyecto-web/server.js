const express = require("express");
const session = require("express-session");
const cors = require("cors");
const bcrypt = require("bcrypt");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const port = 3000;

// Middleware CORS
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE']
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, "vistas")));
app.use(express.static(__dirname));

// Configuración de la base de datos
const db = new sqlite3.Database("mydb.sqlite", (err) => {
    if (err) console.error(err.message);

    db.serialize(() => {
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                role TEXT DEFAULT 'user'
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS habitacion (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_number INTEGER UNIQUE,
                room_type TEXT NOT NULL,
                price INTEGER NOT NULL
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS reservas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                check_in_date TEXT,
                check_out_date TEXT,
                habitacion_id INTEGER,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(habitacion_id) REFERENCES habitacion(id)
            )
        `);

        // Insertar 30 habitaciones demo si la tabla está vacía
        db.get("SELECT COUNT(*) as count FROM habitacion", (err, row) => {
            if (err) return console.error("Error al verificar habitaciones:", err.message);

            if (row && row.count === 0) {
                const demoHabitaciones = [];
                const types = ['Estándar Single', 'Estándar Twin', 'Suite'];
                for (let piso = 1; piso <= 3; piso++) {
                    for (let numero = 1; numero <= 10; numero++) {
                        const roomNumber = piso * 100 + numero;
                        const typeIndex = (numero - 1) % 3;
                        const type = types[typeIndex];
                        const price = (type === 'Suite') ? 100000 : 80000;
                        demoHabitaciones.push({
                            number: roomNumber,
                            type,
                            price
                        });
                    }
                }
                const stmt = db.prepare("INSERT INTO habitacion (room_number, room_type, price) VALUES (?, ?, ?)");
                demoHabitaciones.forEach(h => stmt.run(h.number, h.type, h.price));
                stmt.finalize();
                console.log("30 habitaciones demo insertadas con precios");
            }
        });
    });
});

// ========== ENDPOINTS ==========

// Registro de usuario
app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ message: "Todos los campos son obligatorios" });
    }
    db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
        if (err) return res.status(500).json({ message: "Error interno del servidor" });
        if (user) return res.status(409).json({ message: "El email ya está registrado" });

        try {
            const hashedPassword = await bcrypt.hash(password, 10);
            db.run(
                "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
                [name, email, hashedPassword, 'user'],
                function(err) {
                    if (err) return res.status(500).json({ message: "Error al registrar usuario" });
                    res.status(201).json({ message: "Usuario registrado exitosamente" });
                }
            );
        } catch (error) {
            res.status(500).json({ message: "Error en el servidor" });
        }
    });
});

// Login
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'Credenciales inválidas' });
        }
        req.session.user = {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role || 'user'
        };
        res.json({ 
            message: 'Inicio de sesión exitoso', 
            role: user.role || 'user'
        });
    });
});

app.get('/profile', (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'No autenticado' });
    res.json({ user: req.session.user });
});

app.post('/logout', (req, res) => {
    req.session.destroy();
    res.json({ message: 'Sesión cerrada' });
});

// API habitaciones (todas)
app.get("/api/habitaciones", (req, res) => {
    db.all("SELECT * FROM habitacion", [], (err, rows) => {
        err ? res.status(500).json({ message: err.message }) : res.json(rows);
    });
});

// API reservas usuario actual
app.post("/api/reservas", (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'No autenticado' });

    const { check_in_date, check_out_date, habitacion_id } = req.body;
    db.run(
        "INSERT INTO reservas (user_id, check_in_date, check_out_date, habitacion_id) VALUES (?, ?, ?, ?)",
        [req.session.user.id, check_in_date, check_out_date, habitacion_id],
        function(err) {
            if (err) return res.status(500).json({ message: err.message });
            res.json({ id: this.lastID });
        }
    );
});

app.delete('/api/reservas/:id', (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'No autenticado' });

    db.run(
        "DELETE FROM reservas WHERE id = ? AND user_id = ?",
        [req.params.id, req.session.user.id],
        function(err) {
            if (err) return res.status(500).json({ message: err.message });
            res.sendStatus(204);
        }
    );
});

app.get('/api/mis-reservas', (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'No autenticado' });

    db.all(`
        SELECT r.id, r.check_in_date, r.check_out_date, h.room_number, h.room_type 
        FROM reservas r
        JOIN habitacion h ON r.habitacion_id = h.id
        WHERE r.user_id = ?`,
        [req.session.user.id],
        (err, rows) => err ? res.status(500).json({ message: err.message }) : res.json(rows)
    );
});

// ========== ADMIN ENDPOINTS ==========

// Ver todas las reservas (admin)
app.get('/api/admin/reservas', (req, res) => {
    if (!req.session.user || req.session.user.role !== 'admin') {
        return res.status(403).json({ message: 'Acceso no autorizado' });
    }
    db.all(`
        SELECT r.id, u.name as cliente, u.email, r.check_in_date, r.check_out_date, 
               h.room_number, h.room_type, h.price
        FROM reservas r
        JOIN users u ON r.user_id = u.id
        JOIN habitacion h ON r.habitacion_id = h.id
        ORDER BY r.check_in_date DESC
    `, [], (err, rows) => {
        if (err) return res.status(500).json({ message: err.message });
        res.json(rows);
    });
});

// Eliminar reserva (admin)
app.delete('/api/admin/reservas/:id', (req, res) => {
    if (!req.session.user || req.session.user.role !== 'admin') {
        return res.status(403).json({ message: 'Acceso no autorizado' });
    }
    db.run(
        "DELETE FROM reservas WHERE id = ?",
        [req.params.id],
        function(err) {
            if (err) return res.status(500).json({ message: err.message });
            res.sendStatus(204);
        }
    );
});

// Editar habitación (admin)
app.put('/api/habitaciones/:id', (req, res) => {
    if (!req.session.user || req.session.user.role !== 'admin') {
        return res.status(403).json({ message: 'Acceso no autorizado' });
    }
    const { room_number, room_type, price } = req.body;
    db.run(
        "UPDATE habitacion SET room_number = ?, room_type = ?, price = ? WHERE id = ?",
        [room_number, room_type, price, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ message: err.message });
            res.json({ success: true });
        }
    );
});

// ========== MÉTODO TEMPORAL PARA CREAR ADMIN ==========
app.get('/hazmeadmin', (req, res) => {
    const email = req.query.email;
    if (!email) return res.status(400).send("Agrega ?email=tu@email.com a la URL");
    db.run(
        "UPDATE users SET role = 'admin' WHERE email = ?",
        [email],
        function(err) {
            if (err) return res.status(500).send("Error: " + err.message);
            if (this.changes === 0) return res.send("Usuario no encontrado");
            res.send(`¡Usuario ${email} convertido a admin!`);
        }
    );
});

// ========== RUTAS HTML ==========
app.get(["/", "/login"], (req, res) => res.sendFile(path.join(__dirname, "vistas", "login.html")));
app.get("/register", (req, res) => res.sendFile(path.join(__dirname, "vistas", "login.html")));
app.get("/reservas", (req, res) => res.sendFile(path.join(__dirname, "vistas", "reservas.html")));
app.get("/user-account", (req, res) => res.sendFile(path.join(__dirname, "vistas", "user-account.html")));
app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "vistas", "admin.html")));

app.listen(port, () => console.log(`Servidor en puerto ${port}`));
