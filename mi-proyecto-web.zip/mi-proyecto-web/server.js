const express = require("express");
const session = require("express-session");
const cors = require("cors");
const bcrypt = require("bcrypt");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const port = 3000;

// Middleware CORS
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE']
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, "vistas")));
app.use(express.static(__dirname));

// Configuración de la base de datos
const db = new sqlite3.Database("mydb.sqlite", (err) => {
    if (err) console.error(err.message);

    db.serialize(() => {
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                role TEXT DEFAULT 'user'
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS habitacion (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_number INTEGER UNIQUE,
                room_type TEXT NOT NULL,
                price INTEGER NOT NULL
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS reservas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                check_in_date TEXT,
                check_out_date TEXT,
                habitacion_id INTEGER,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(habitacion_id) REFERENCES habitacion(id)
            )
        `);

        // Insertar 30 habitaciones demo si la tabla está vacía
        db.get("SELECT COUNT(*) as count FROM habitacion", (err, row) => {
            if (err) return console.error("Error al verificar habitaciones:", err.message);
            if (row && row.count === 0) {
                const demoHabitaciones = [];
                const types = ['Estándar Single', 'Estándar Twin', 'Suite'];
                for (let piso = 1; piso <= 3; piso++) {
                    for (let numero = 1; numero <= 10; numero++) {
                        const roomNumber = piso * 100 + numero;
                        const typeIndex = (numero - 1) % 3;
                        const type = types[typeIndex];
                        const price = (type === 'Suite') ? 100000 : 80000;
                        demoHabitaciones.push({
                            number: roomNumber,
                            type,
                            price
                        });
                    }
                }
                const stmt = db.prepare("INSERT INTO habitacion (room_number, room_type, price) VALUES (?, ?, ?)");
                demoHabitaciones.forEach(h => stmt.run(h.number, h.type, h.price));
                stmt.finalize();
                console.log("30 habitaciones demo insertadas con precios");
            }
        });
    });
});

// ========== ENDPOINTS ==========

// Registro de usuario
app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ message: "Todos los campos son obligatorios" });
    }
    db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
        if (err) return res.status(500).json({ message: "Error interno del servidor" });
        if (user) return res.status(409).json({ message: "El email ya está registrado" });

        try {
            const hashedPassword = await bcrypt.hash(password, 10);
            db.run(
                "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
                [name, email, hashedPassword, 'user'],
                function(err) {
                    if (err) return res.status(500).json({ message: "Error al registrar usuario" });
                    res.status(201).json({ message: "Usuario registrado exitosamente" });
                }
            );
        } catch (error) {
            res.status(500).json({ message: "Error en el servidor" });
        }
    });
});

// Login
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
        if (err) return res.status(500).json({ message: "Error de base de datos" });
        if (!user) return res.status(401).json({ message: "Usuario no encontrado" });
        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(401).json({ message: 'Credenciales inválidas' });

        req.session.user = {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role || 'user'
        };
        req.session.save((err) => {
            if (err) return res.status(500).json({ message: "Error al guardar sesión" });
            res.json({ 
                message: 'Inicio de sesión exitoso', 
                role: user.role || 'user'
            });
        });
    });
});

app.get('/profile', (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'No autenticado' });
    res.json({ user: req.session.user });
});

app.post('/logout', (req, res) => {
    req.session.destroy();
    res.json({ message: 'Sesión cerrada' });
});

// API habitaciones (todas)
app.get("/api/habitaciones", (req, res) => {
    db.all("SELECT * FROM habitacion", [], (err, rows) => {
        err ? res.status(500).json({ message: err.message }) : res.json(rows);
    });
});

// Endpoint: habitaciones disponibles para fechas seleccionadas
app.post('/api/habitaciones-disponibles', (req, res) => {
    const { check_in_date, check_out_date } = req.body;
    if (!check_in_date || !check_out_date) {
        return res.status(400).json({ message: 'Fechas requeridas' });
    }
    const query = `
        SELECT h.* FROM habitacion h
        WHERE h.id NOT IN (
            SELECT r.habitacion_id FROM reservas r
            WHERE (date(r.check_in_date) < date(?) AND date(r.check_out_date) > date(?))
        )
    `;
    db.all(query, [check_out_date, check_in_date], (err, rows) => {
        if (err) return res.status(500).json({ message: err.message });
        res.json(rows);
    });
});

// API reservas usuario actual (con validación de disponibilidad)
// SOLO USUARIOS NORMALES PUEDEN CREAR RESERVAS
app.post("/api/reservas", (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'No autenticado' });
    if (req.session.user.role !== 'user') {
        return res.status(403).json({ message: 'Solo los usuarios pueden crear reservas.' });
    }

    const { check_in_date, check_out_date, habitacion_id } = req.body;

    // Validación básica de fechas
    if (!check_in_date || !check_out_date || !habitacion_id) {
        return res.status(400).json({ message: "Todos los campos son obligatorios" });
    }
    if (new Date(check_in_date) >= new Date(check_out_date)) {
        return res.status(400).json({ message: "La fecha de check-out debe ser posterior al check-in" });
    }

    // Validar disponibilidad
    const query = `
        SELECT COUNT(*) as count FROM reservas 
        WHERE habitacion_id = ? 
        AND (
            (date(check_in_date) < date(?) AND date(check_out_date) > date(?))
        )
    `;
    db.get(query, [
        habitacion_id,
        check_out_date, check_in_date
    ], (err, row) => {
        if (err) return res.status(500).json({ message: err.message });
        if (row.count > 0) {
            return res.status(400).json({ message: 'La habitación no está disponible en las fechas seleccionadas' });
        }

        // Crear reserva
        db.run(
            "INSERT INTO reservas (user_id, check_in_date, check_out_date, habitacion_id) VALUES (?, ?, ?, ?)",
            [req.session.user.id, check_in_date, check_out_date, habitacion_id],
            function(err) {
                if (err) return res.status(500).json({ message: err.message });
                res.json({ id: this.lastID });
            }
        );
    });
});

// Eliminar reserva del usuario actual
app.delete('/api/reservas/:id', (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'No autenticado' });

    db.run(
        "DELETE FROM reservas WHERE id = ? AND user_id = ?",
        [req.params.id, req.session.user.id],
        function(err) {
            if (err) return res.status(500).json({ message: err.message });
            res.sendStatus(204);
        }
    );
});

app.get('/api/mis-reservas', (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'No autenticado' });

    db.all(`
        SELECT r.id, r.check_in_date, r.check_out_date, h.room_number, h.room_type 
        FROM reservas r
        JOIN habitacion h ON r.habitacion_id = h.id
        WHERE r.user_id = ?`,
        [req.session.user.id],
        (err, rows) => err ? res.status(500).json({ message: err.message }) : res.json(rows)
    );
});

// ========== ADMIN ENDPOINTS ==========

// Ver todas las reservas (admin) - ROBUSTO Y A PRUEBA DE ERRORES
app.get('/api/admin/reservas', (req, res) => {
    if (!req.session.user || req.session.user.role !== 'admin') {
        return res.status(403).json({ message: 'Acceso no autorizado' });
    }
    db.all(`
        SELECT r.id, 
               IFNULL(u.name, 'Usuario eliminado') as cliente, 
               IFNULL(u.email, 'N/A') as email, 
               r.check_in_date, r.check_out_date, 
               IFNULL(h.room_number, 'Eliminada') as room_number, 
               IFNULL(h.room_type, 'Eliminada') as room_type, 
               IFNULL(h.price, 0) as price
        FROM reservas r
        LEFT JOIN users u ON r.user_id = u.id
        LEFT JOIN habitacion h ON r.habitacion_id = h.id
        ORDER BY r.check_in_date DESC
    `, [], (err, rows) => {
        if (err) {
            console.error("Error al obtener reservas admin:", err.message);
            return res.status(500).json({ message: err.message });
        }
        res.json(rows);
    });
});

// Eliminar reserva (admin)
app.delete('/api/admin/reservas/:id', (req, res) => {
    if (!req.session.user || req.session.user.role !== 'admin') {
        return res.status(403).json({ message: 'Acceso no autorizado' });
    }
    db.run(
        "DELETE FROM reservas WHERE id = ?",
        [req.params.id],
        function(err) {
            if (err) return res.status(500).json({ message: err.message });
            res.sendStatus(204);
        }
    );
});

// Editar habitación (admin)
app.put('/api/habitaciones/:id', (req, res) => {
    if (!req.session.user || req.session.user.role !== 'admin') {
        return res.status(403).json({ message: 'Acceso no autorizado' });
    }
    const { room_number, room_type, price } = req.body;
    db.run(
        "UPDATE habitacion SET room_number = ?, room_type = ?, price = ? WHERE id = ?",
        [room_number, room_type, price, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ message: err.message });
            res.json({ success: true });
        }
    );
});

// Endpoint para convertir usuario en admin
app.get('/hazmeadmin', (req, res) => {
    const email = req.query.email;
    if (!email) return res.status(400).send('Falta el parámetro email');
    db.run("UPDATE users SET role = 'admin' WHERE email = ?", [email], function(err) {
        if (err) return res.status(500).send('Error al actualizar');
        if (this.changes === 0) return res.send('Usuario no encontrado');
        res.send(`¡Usuario ${email} convertido a admin!`);
    });
});

// ========== RUTAS HTML ==========
app.get(["/", "/login"], (req, res) => res.sendFile(path.join(__dirname, "vistas", "login.html")));
app.get("/register", (req, res) => res.sendFile(path.join(__dirname, "vistas", "login.html")));
app.get("/reservas", (req, res) => res.sendFile(path.join(__dirname, "vistas", "reservas.html")));
app.get("/user-account", (req, res) => res.sendFile(path.join(__dirname, "vistas", "user-account.html")));
app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "vistas", "admin.html")));

app.listen(port, () => console.log(`Servidor activo en http://localhost:${port}`));
