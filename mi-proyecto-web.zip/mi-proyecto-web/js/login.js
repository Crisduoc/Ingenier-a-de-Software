const loginForm = document.getElementById('login-form');
const errorMessage = document.getElementById('error-message');

loginForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const email = document.getElementById('username').value; // El ID en tu HTML es "username", pero en realidad es el email
    const password = document.getElementById('password').value;

    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    })
    .then(response => {
        if (!response.ok) {
            // Si la respuesta no es exitosa (4xx o 5xx), intenta obtener el JSON del error
            return response.json().then(data => {
                // Lanza un error con el mensaje del servidor, o un mensaje genérico
                throw new Error(data.message || 'Error desconocido al iniciar sesión');
            });
        }
        return response.json(); // Si la respuesta es 2xx, parsea el JSON
    })
    .then(data => {
        if (data.message === 'Inicio de sesión exitoso') {
            console.log('Inicio de sesión exitoso:', data);
            // Redirige basado en el rol del usuario
            if (data.role === 'admin') {
                window.location.href = 'admin.html';
            } else if (data.role === 'recepcionista') {
                window.location.href = 'reservas.html'; // Asegúrate de que esta página exista
            } else {
                window.location.href = 'index.html'; // O a donde quieras redirigir a usuarios normales
            }
        } else {
            // Muestra el mensaje de error del servidor
            errorMessage.textContent = data.message || 'Error desconocido al iniciar sesión';
        }
    })
    .catch(error => {
        // Captura errores de la petición fetch y errores lanzados por el bloque then anterior
        console.error('Error:', error);
        errorMessage.textContent = error.message || 'Error al conectar con el servidor';
    });
});